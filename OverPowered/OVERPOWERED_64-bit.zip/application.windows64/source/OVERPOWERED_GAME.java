import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class OVERPOWERED_GAME extends PApplet {

// Constant values to be used in conjuction with other methods to produce animation 
final int IDLE = 1;     // player idle value  
final int LEFT_RUN = 5;    // player running left value
final int RIGHT_RUN = 5;     // player running right value
final int NPC_Run = 7;  // NPC movement value

// Initialises when switched to GAME state
public void startGame()
{   
  gameState = STATE_GAME;     // current game state
  playerPosX = 200;           // player's initial x value
  playerPosY= height/2;       // player's initial y value

  loadIdleFrames();           

  // initialises the minim instance as 'sound'
  sound = new Minim(this);

  // loads music track into 'player1'
  player1 = sound.loadFile("Captain Commando music - City.mp3");                      // Reference 4a
  // plays and loops the track 
  player1.loop();

  // loads music tracks for respective players
  player2 = sound.loadFile("Captain Commando Theme-Marvel VS Capcom Music.mp3");     // Reference 4b
  player3 = sound.loadFile("Another Winter.mp3");                                    // Reference 4c
  player4 = sound.loadFile("Mega Man 2 Dr. Wily Stage 1 -- Epic Game Music.mp3");    // Reference 4d

  // Sets the average gain of track to -45dB
  player1.setGain(-45);
  player2.setGain(-45);
  player3.setGain(-45);
  player4.setGain(-45);

  // loads dying sound effect
  dyingSFX = sound.loadSample("Scott Pilgrim K.O. Sound Effect.mp3");                // Reference 4e

  // only 'player1' plays when game is setup
  player1Active = true;
  player2Active = false;
  player3Active = false;
  player4Active = false;

  NPCList = new ArrayList<NPC>(); // initialising the list 

  // Create first enemy
  NPCList.add(createNPC());

  // Stages
  bg = loadImage("Stage1.png"); // Reference 5b

  gameActive = true;            // Game is active
}

/**
 * Subfunction for drawing the screen when in GAME state.
 */
public void draw_Game() 
{
  // draws game when its boolean is activated.
  if (gameActive)
  {  
    background(bg);            // stage background

    // draws text for kills  
    stroke(0);
    fill(random(150, 256));
    textSize(21);
    textAlign(CENTER);
    text("KILLS: " + kills, width-55, 20 );    // the intger of kills adds to text 

    // draws the remaining text
    fill(white);
    textSize(21);
    textAlign(CORNER);
    text("Press ENTER to quit to Menu", 10, 20 );
    text("Press P to end simulation", 10, 45);     

    // generates player
    animatePlayer();
    drawPlayer();

    // creates a temporary NPC object from the NPC class 
    NPC tempNPC=null;

    // draws a new NPC if it has not been killed
    for (NPC npc : NPCList) {    
      if (!killed) {

        npc.animateNPC();
        npc.drawNPC();

        // collision detection between player and NPC.
        if ( dist(playerPosX, 0, npc.NPCPosX, 0) <=  5) 
        {
          tempNPC = npc;            // temporary NPC gets assigned as npc
          dyingSFX.trigger();       // dying sound effect is played
          dyingSFX.setGain(-36);    // sets the gain to be higher than background track.
          kills++;                  // total kills increases
        }
      }
    }

    // when temporary NPC is not null, then removes from screen
    if (tempNPC != null) {  
      NPCList.remove(tempNPC);
    }

    // load relavent frames, when moving to the right.
    if (keyCode == RIGHT) 
    {
      loadRightRunFrames();
    }


    // load relavent frames, when moving to the left.
    if (keyCode == LEFT)
    {

      loadLeftRunFrames();
    }

    // invisble wall on left
    if ( playerPosX <= 40)
    {
      playerPosX = 40;
    }

    // invisble wall on right
    if ( playerPosX >= width-40)
    {
      playerPosX = width-40;
    }
  }
}

/**
 * Subfunction for handling key presses when in GAME state.
 */
public void keyPressed_Game()
{
  // transition frames if moving right.
  if (keyCode == RIGHT) {
    animatePlayerRunRight();
    drawPlayer();
    playerPosX= playerPosX+3;          // increases player's velocity
  }

  // transition frames if moving left.
  if (keyCode == LEFT) {

    animatePlayerRunLeft();
    drawPlayer();
    playerPosX= playerPosX-3;          // increases player's velocity
  }

  // spawns new npc
  if (key == ' ')
  {
    NPCList.add(createNPC());
  }

  // opens menu, while deactiving GAME state and pauses background music
  if ( keyCode == ENTER )
  {
    openMenu();
    gameActive = false;
    player1.pause();
    player2.pause();
    player3.pause();
    player4.pause();
  }

  // changes background to stage 1
  if (key == 'q')
  {
    bg = loadImage("Stage1.png");      // Reference 5b
  }

  // changes background to stage 2
  if (key == 'w')
  {
    bg = loadImage("Stage2.png");     // Reference 5b
  }

  // changes background to stage 3
  if (key == 'e')
  {
    bg = loadImage("Stage3.png");    // Reference 5b
  }

  // changes background to stage 4
  if (key == 'r')
  {
    bg = loadImage("Stage4.png");    // Reference 5b
  }

  // stops other background song and activates player 1
  if (key == '1' &&  !player1Active)
  {
    player2.pause();
    player3.pause();
    player4.pause();
    player1.loop();
    player1Active = true;
    player2Active = false;
    player3Active = false;
    player4Active = false;
  }

  // stops other background song and activates player 2
  if (key == '2' &&  !player2Active)
  {
    player1.pause();
    player3.pause();
    player4.pause();
    player2.loop();
    player1Active = false;
    player2Active = true;
    player3Active = false;
    player4Active = false;
  }

  // stops other background song and activates player 3
  if (key == '3' &&  !player3Active)
  {
    player1.pause();
    player2.pause();
    player4.pause();
    player3.loop();
    player1Active = false;
    player2Active = false;
    player3Active = true;
    player4Active = false;
  }

  // stops other background song and activates player 4
  if (key == '4' &&  !player4Active)
  {
    player1.pause();
    player2.pause();
    player3.pause();
    player4.loop();
    player1Active = false;
    player2Active = false;
    player3Active = false;
    player4Active = true;
  }

  // Changes to END state
  if (key == 'p')
  {
    endGame();
  }
}

/**
 * COMP570 Programming for Creativity 2015 S1
 *
 * OVERPOWERED: SIMULATOR 2015 B.C. Ultra Super Turbo Arcade Edition Version
 *
 * This is program is a game (simulator) for reliving stress. The program is modelled as a basic 
 * beat 'em up, where the player is kept inside of a screen.
 * Additionally, the background and sound can be changed in realtime. 
 * In this simulator the character is overpowered, thus there is no difficulty.
 * But, there are a few secrets hidden in the game/code. 
 *
 * References:
 * 1. Character Spritesheet: http://www.spriters-resource.com/arcade/capcommand/sheet/55189/
 *
 * 2. NPC Spritesheet: http://www.spriters-resource.com/arcade/capcommand/sheet/54705/
 *
 * 3. Backgrounds:
 * a. http://imagizer.imageshack.com/download/19/pssmst6a.png
 * b. http://indiegamehq.com/introducing-beating-quota-riot-themed-beat-em-decaying-logic/
 * 
 * 4. Sound:
 * a. https://www.youtube.com/watch?v=orcrbhbShKc
 * b. https://www.youtube.com/watch?v=PdW4P2O95B8
 * c. https://www.youtube.com/watch?v=BkF2cmBx8a8
 * d. https://www.youtube.com/watch?v=JTSFsGUlJzg
 * e. https://www.youtube.com/watch?v=fVPJuGIuUMU
 * f. https://www.youtube.com/watch?v=D9HRqJY1Yz8
 *
 * 5. Images:
 * a. http://diabalzane.com/wp-content/uploads/2014/05/Personnages-celebres-Troll-face-260360.png
 * b. Multiple images from google images (Some of which have been PhotoShopped).
 *
 * 6. Video Links:
 * a. https://www.youtube.com/watch?v=xfr64zoBTAQ
 * b. https://www.youtube.com/watch?v=pzDgaGTARqE
 *
 * 7. Code:
 * a. GameStates posted on Blackboard by Stefan.
 * b. Lecture 09 (P.g. 38-40).
 * c. Multiple pieces of codes from material taught over the semestar.  
 *
 *@author Sujay Chand
 *@version 1.0 - 03.06.2015: Created
 */

// use the minim library


AudioPlayer player1, player2, player3, player4;

AudioSample dyingSFX, nextBattle;

Minim sound;

// Constants representing states of the game
final int STATE_INTRO = 0;
final int STATE_GAME = 1;
final int STATE_MENU = 2;
final int STATE_END = 3;
final int STATE_TROLL = 4;

/** 
 * Global variables
 */

int gameState;                 // current state of game
int white = color(255);      // labeling white's global variable 
int black = color(0);        // labeling black's global variable 

// Variables used in the MENU state
PImage menuBG;
int rightKeyPressed;

/**
 * Variables used mainly in GAME state
 */

PImage bg;                              // background image for GAME state

// Varibles for player
PImage[]   playerFrames;              // player's current frame
int        playerFrameIdx;            // player's index frame 
float      playerPosX, playerPosY;    // player's x and y coordinate
int        kills;                     // amount of enemies killed by player

// Varibles for NPC
ArrayList<NPC> NPCList;               // list for NPC is initially null
boolean        killed;                // checks if NPC has been killed

// Checks if respective audio players are playing and stops tracks from overlapping
boolean player1Active;
boolean player2Active;
boolean player3Active;
boolean player4Active;

// checks if game is running
boolean gameActive;

// Varible for TROLL state
PImage Troll;                        // image for TROLL state

// Initialises setup
public void setup()
{
  size(900, 400);
}

public void draw()
{
  // assigns the appropriate draw subfunction, depending on the game state 
  switch (gameState)
  {
  case STATE_INTRO : 
    draw_Intro(); 
    break;
  case STATE_MENU : 
    draw_Menu(); 
    break;
  case STATE_GAME : 
    draw_Game(); 
    break;
  case STATE_END : 
    draw_End(); 
    break;
  case STATE_TROLL : 
    draw_Troll(); 
    break;
  }
}

public void keyPressed() 
{
  // assigns the appropriate draw subfunction, depending on the game state
  switch ( gameState )
  {
  case STATE_INTRO : 
    keyPressed_Intro(); 
    break;
  case STATE_MENU : 
    keyPressed_Menu(); 
    break;
  case STATE_GAME : 
    keyPressed_Game(); 
    break;
  case STATE_END : 
    keyPressed_End(); 
    break;
  case STATE_TROLL : 
    keyPressed_Troll(); 
    break;
  }

  // when 'ESC' key is pressed, opens link to video (an add-on to troll function's purpose)
  if (keyCode == ESC)
  {
    link("https://www.youtube.com/watch?v=xfr64zoBTAQ");               // Reference 6a
  }
}

public void mousePressed()
{
  // when mouse is pressed, mimics the function assigned to 'ESC'
  link("https://www.youtube.com/watch?v=xfr64zoBTAQ");                // Reference 6a
}

public void stop() {
  // cleans up the sound
  player1.close();
  player1 = null;
  player2.close();
  player2 = null;
  player3.close();
  player3 = null;
  player4.close();
  player4 = null;
  dyingSFX.close();
  dyingSFX = null;
  nextBattle.close();
  nextBattle = null;

  // cleans the Minim instance
  sound.stop();
  sound = null;
  // stops the rest of the program
  super.stop();
}

/**
 * Introduction Function (STATE_INTRO)
 */

/**
 * Begins the game.
 */
public void beginGame()
{
  gameState = STATE_INTRO;       // checks state
}

/**
 * Subfunction for drawing the screen when in INTRO state.
 */
public void draw_Intro()
{
  background(black);      // draws black background

  // First Line of game's title
  stroke(0);
  fill(white);
  textSize(50);
  textAlign(CENTER);
  text("OVERPOWERED:", width/2, height/8 );

  // second line of game's title
  textSize(40);
  text("SIMULATOR 2015 B.C.", width/2, 95 );

  // instuctional text
  textSize(30);
  text("Press ENTER to BEGIN", width/2, height*2/3 );
  text("Press T to OPEN my BLOG", width/2, height*4/5);

  // third line of game's title
  fill(random(256), random(256), random(256));
  textSize(25);
  text("Ultra Super Turbo Arcade Edition Version", width/2, 145);

  // author's text
  fill(155);
  textSize(20);
  textAlign(CORNER);
  text("CREATED BY: SUJAY GAURAV CHAND", 5, height-7);
}

/**
 * Subfunction for handling key presses when in INTRO state.
 */
public void keyPressed_Intro() 
{
  // changes to MENU state
  if ( keyCode == ENTER )
  {
    openMenu();
  }

  // opens my blog
  if ( key == 't')
  {
    link("http://isthisprogress.tumblr.com");          
  }
}

/**
 * Menu Function (STATE_MENU)
 */

/**
 * Opens game menu.
 */
public void openMenu()
{
  gameState = STATE_MENU;                 // checks state

  menuBG = loadImage("Menu0.png");        // assinging content to the variable

    rightKeyPressed = 0;                    // right key has been pressed zero times
}

/**
 * Subfunction for drawing the screen when in MENU state.
 */
public void draw_Menu()
{
  background(menuBG);                                // draws background with the current value

  // skipping state text
  stroke(0);
  fill(random(150, 256));
  textSize(18);
  textAlign(CENTER);
  text("Press ENTER to Skip", width/2, height-15 );

  // adds the content listed below, if right key has been pressed 0 times
  if (rightKeyPressed == 0)
  {
    menuBG = loadImage("Menu0.png");
    stroke(0);
    fill(random(150, 256));
    textSize(18);
    textAlign(CORNERS);
    text("NEXT", width-120, height-15 );
  }

  // adds the content listed below, if right key has been pressed 1 times
  if (rightKeyPressed == 1)
  {
    menuBG = loadImage("Menu1.png");
    stroke(0);
    fill(random(150, 256));
    textSize(18);
    textAlign(CORNERS);
    text("NEXT", width-120, height-15 );

    stroke(0);
    fill(random(150, 256));
    textSize(18);
    textAlign(CORNER);
    text("BACK", 75, height-15 );
  }

  // adds the content listed below, if right key has been pressed 0 times
  if (rightKeyPressed == 2)
  {
    menuBG = loadImage ("Menu2.png");

    stroke(0);
    fill(random(150, 256));
    textSize(18);
    textAlign(CORNERS);
    text("NEXT", width-120, height-15 );

    stroke(0);
    fill(random(150, 256));
    textSize(18);
    textAlign(CORNER);
    text("BACK", 75, height-15 );
  }

  // adds the content listed below, if right key has been pressed 0 times
  if (rightKeyPressed == 3)
  {
    menuBG = loadImage("Menu3.png");

    stroke(0);
    fill(random(150, 256));
    textSize(18);
    textAlign(CORNER);
    text("BACK", 75, height-15 );
  }
}

/**
 * Subfunction for handling key presses when in MENU state.
 */
public void keyPressed_Menu()
{
  // changes to GAME state and resets the variables, for next playthrough
  if ( keyCode == ENTER )
  {
    startGame();
    playerFrameIdx = 0;
    kills = 0;
  }

  // increase the values of 'rightKeyPressed'
  if (keyCode == RIGHT)
  {
    rightKeyPressed = rightKeyPressed + 1;

    if (rightKeyPressed > 3)
    {
      rightKeyPressed = 3;        // does not allow value to exceed 3
    }
  }

  // decrease the values of 'rightKeyPressed'
  if (keyCode == LEFT)
  {
    rightKeyPressed = rightKeyPressed - 1;

    if (rightKeyPressed < 0)
    {
      rightKeyPressed = 0;        // does not allow value to drop below 0
    }
  }
}

/**
 * This tab contains the methods for the playable character
 *
 * This enitre tab uses Reference 1 and 7a.
 *
 */

// loads player in Idle
public void loadIdleFrames()
{
  // reserve memory for images
  playerFrames = new PImage[1];

  //loadimages
  for ( int i = 0; i< playerFrames.length; i++)
  {
    // searches for files (in data folder) with "Standing" and a number extension unitl 1. 
    String filename = "Standing" + (i+1) + ".png";  
    playerFrames[i] = loadImage(filename);          // shows loaded frame
  }
}


// Animates player in Idle stance (with its single frame)
public void animatePlayer()
{
  if ( frameCount % IDLE == 1)
  {
    playerFrameIdx++;
  }
}

// load player's left running frames
public void loadLeftRunFrames()
{
  // reserve memory for images
  playerFrames = new PImage[6];

  // loadimages
  for ( int i = 0; i<playerFrames.length; i++)
  {
    // searches for files (in data folder) with "LeftRunning" and a number extension unitl 6
    String filename = "LeftRunning" + (i+1) + ".png";
    playerFrames[i] = loadImage(filename);              // shows loaded frame at that instance
  }
}

// animate player's left frames
public void animatePlayerRunLeft()
{
  if ( frameCount % LEFT_RUN == 0)      // show frame 'div/0' + Remainder 
  {
    playerFrameIdx++;              // adds next frame if remainder exists
    if ( playerFrameIdx >= playerFrames.length ) 
    {
      // resets the player frame index if it exceeds 5 (look at prior method)
      playerFrameIdx = 0;
    }
  }
  playerPosX--; // move character position left
}

// load player's right running frames
public void loadRightRunFrames()
{
  // reserve memory for images
  playerFrames = new PImage[6];
  // loadimages
  for ( int i = 0; i<playerFrames.length; i++)
  {
    // searches for files (in data folder) with "Running" and a number extension unitl 6
    String filename = "Running" + (i+1) + ".png";
    playerFrames[i] = loadImage(filename);            // shows loaded frame at that instance
  }
}

// animate player's right frames
public void animatePlayerRunRight()
{
  if ( frameCount % RIGHT_RUN == 0)      // show frame 'div/0' + Remainder 
  {
    playerFrameIdx++;              // adds next frame if remainder exists
    if ( playerFrameIdx >= playerFrames.length ) 
    {
      // resets the player frame index if it exceeds 5 (look at prior method)
      playerFrameIdx = 0;
    }
  }
  playerPosX++; // move character position right
}

// draws player
public void drawPlayer()
{
  imageMode(CORNER);
  // player is 87x79 pixels: offset - 40/-45 to place feet at playerPosX/playerPosY
  image(playerFrames[playerFrameIdx], playerPosX -40, playerPosY +45);

  // creates red dot above player, to keep track of his location when screen is overcrowded
  stroke(color(255, 0, 0));
  ellipse(playerPosX, playerPosY, 2, 2);
}

/**
 * Class for NPC
 * 
 * This enitre tab uses Reference 2 and 7a.
 *
 */
class NPC
{
  // Properties of the NPC
  PImage[]     NPCFrames;          // NPC's current frame
  int          NPCFrameIdx;        // NPC's index frame 
  float        NPCPosX, NPCPosY;   // NPC's x and y coordinate
  boolean      MoveRight;          // checks if NPC is moving right

  /**
   * Constructor for a NPC instance.
   */
  NPC( boolean isMoveRight) {
    NPCPosY =  height/2;          // places NPC at its y coordinate
    MoveRight = isMoveRight;      // moving right
    NPCFrames = new PImage[8];    // reserves memory for images
    killed = false;               // NPC has not been killed.......yet

    // values if constructor is true 
    if (isMoveRight == true)
    {
      NPCPosX = 0;              // NPC's x coordinate

      for ( int i = 0; i< NPCFrames.length; i++)
      {
        // searches for files (in data folder) with "Running" and a number extension unitl 8
        String filename = "EnemyRunningRight" + (i+1) + ".png";
        NPCFrames[i] = loadImage(filename);                      // shows loaded frame at that instance
      }
    } else
    {
      NPCPosX = width;
      for ( int i = 0; i< NPCFrames.length; i++)
      {
        // searches for files (in data folder) with "Running" and a number extension unitl 8
        String filename = "EnemyRunningLeft" + (i+1) + ".png";
        NPCFrames[i] = loadImage(filename);                     // shows loaded frame at that instance
      }
    }
  }

  // animates and moves NPC
  public void animateNPC()
  {
    if ( frameCount % NPC_Run == 0)               // show frame 'div/0' + Remainder 
    {
      NPCFrameIdx++;                             // adds next frame if remainder exists
      if ( NPCFrameIdx >= NPCFrames.length )
      {
        // resets the player frame index if it exceeds 7 (look at NPCFrames in construtor)
        NPCFrameIdx = 0;
      }
    }
    if (MoveRight) {
      NPCPosX++;            // move NPC position right
    } else { 
      NPCPosX--;            // move NPC position left
    }
  }

  // draws NPC
  public void drawNPC()
  {
    imageMode(CORNER);
    // NPC is 109x103 pixels: offset -40/+30 to place feet at playerPosX/playerPosY
    image(NPCFrames[NPCFrameIdx], NPCPosX-40, NPCPosY +30);
  }
}

/**
 * Randomly selects a true or false value
 */
public NPC createNPC() {
  float randomNumber = random(1);          // generates a random number
  boolean MoveRight;                       // temporary boolean 
  if (randomNumber >= 0.45f) {
    
    // 54%/99% chance that the NPC moves to the right
    MoveRight = true;
  } else {
    
    // 45%/99% chance that the NPC moves to the right
    MoveRight = false;
  }
  
  // makes a new temporary NPC variable function to return the random boolean value.
  NPC npc = new NPC(MoveRight);
  return npc;
}

/**
 * Game Ending Function (STATE_END)
 */

/**
 * Ends the game(Playable Section).
 */
public void endGame()
{
  gameState = STATE_END;
  gameActive = false;                // stops game from running in background

  // initialise the minim instance as 'sound' in this state
  sound = new Minim(this);

  // loads a sound sample into a variable 
  nextBattle = sound.loadSample("GET READY FOR THE NEXT BATTLE! - TEKKEN 5 OST.mp3"); // Reference 4f
}

/**
 * Subfunction for drawing the screen when in END state.
 */
public void draw_End()
{
  background(125, 125, 0, 155);          // draws background with an aesthetically pleasing colour 

  // end game text
  stroke(0);
  fill(white);
  textSize(30);
  textAlign(CENTER);
  text("END OF LEVEL FOR THIS SIMULATION", width/2, height/5 );
  text("KILLS: " + kills, width/2, height*3/5 );
  fill(random(130, 256));
  text("PRESS ANY KEY FOR BOSS LEVEL", width/2, height*3/4 );
}

/**
 * Subfunction for handling key presses when in END state.
 */
public void keyPressed_End()
{
  // changes to TROLL state
  beginTroll();
  
  // Pauses all background music
  player1.pause();
  player2.pause();
  player3.pause();
  player4.pause();

  // plays sound with a reduced gain
  nextBattle.setGain(-36);
  nextBattle.trigger();
}

/**
 * Trolling Function (STATE_TROLL)
 */

/**
 * Begins the trolling section.
 */
public void beginTroll() 
{
  gameState = STATE_TROLL;

  Troll = loadImage("Troll.png");                // Reference 5a
}

/**
 * Subfunction for drawing the screen when in TROLL state.
 */
public void draw_Troll()
{
  // background is tranparent, so the image is drawn directly above the previous state
  noFill();                               
  imageMode(CENTER);
  image(Troll, width/2, height/2, 500, 400);
}

/**
 * Subfunction for handling key presses when in TROLL state.
 */
public void keyPressed_Troll()
{
  link("https://www.youtube.com/watch?v=pzDgaGTARqE");    // opens link to a video (Reference 7b)
  beginGame();                                            // goes back to INTRO state
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "OVERPOWERED_GAME" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
